"""
CPU smoke test on synthetic data. Verifies that every model trains, that the
CCI intervention runs and returns sane shapes, that the manipulation check
holds for the shared-lattice models, and that the statistics and plots execute.

It does not download CIFAR and it does not check accuracy. Run:
    python smoke_test.py
"""

import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset

from config import (ModelConfig, TrainConfig, CCIConfig, DownstreamConfig,
                    LATTICE_MODELS, NATIVE_MODELS)
from cci.data import DonorPlan
from cci.train import build_model, train_end_to_end, train_two_stage
from cci.experiments import spatial_profile, cci_radius_summary, background_reliance
from cci.analysis import paired_seed_test, pearson_with_ci, plot_spatial_profiles, plot_cci_vs_bggap


def synthetic_loaders(n_train=128, n_eval=200, classes=4, bs=32, seed=0):
    g = torch.Generator().manual_seed(seed)
    def make(n):
        x = torch.randn(n, 3, 32, 32, generator=g)
        y = torch.randint(0, classes, (n,), generator=g)
        return TensorDataset(x, y)
    mk = lambda d, s: DataLoader(d, batch_size=bs, shuffle=s)
    return mk(make(n_train), True), mk(make(n_eval), False), mk(make(n_eval), False), classes


def main():
    device = "cpu"
    torch.set_num_threads(2)

    mcfg = ModelConfig(embed_dim=32, encoder_blocks=1, encoder_mlp_ratio=2,
                       depth=1, n_heads=2, swin_window=4, gat_layers=1,
                       gat_heads=2, cnn_blocks=1)
    tcfg = TrainConfig(epochs=1, encoder_epochs=1, mixer_epochs=1, warmup_epochs=0,
                       amp=False, label_smoothing=0.0)
    ccfg = CCIConfig(target_tokens=[27, 0], radii=[1, 2], n_source=16,
                     n_same_class_donors=2, n_diff_class_donors=2)
    dcfg = DownstreamConfig(foreground_radius=2, n_random_donors=2, n_eval_images=32)

    train_loader, val_loader, test_loader, num_classes = synthetic_loaders()
    loaders = (train_loader, val_loader, test_loader)

    # Build the CCI evaluation tensor and labels from the test loader.
    xs, ys = [], []
    for x, y in test_loader:
        xs.append(x); ys.append(y)
    test_images = torch.cat(xs)
    test_labels = torch.cat(ys).numpy()
    donor_plan = DonorPlan(test_labels, ccfg.n_source, ccfg.n_same_class_donors,
                           ccfg.n_diff_class_donors, ccfg.donor_seed)

    all_models = list(LATTICE_MODELS) + list(NATIVE_MODELS)
    points = []
    radius_by_model = {}

    for name in all_models:
        # end-to-end
        model = build_model(name, mcfg, num_classes)
        acc = train_end_to_end(model, loaders, tcfg, device, seed=1)
        prof = spatial_profile(model, test_images, test_labels, donor_plan, ccfg, device)
        sc = prof["scalars"]
        cci_r = cci_radius_summary(sc, ccfg.target_tokens, ccfg.radii)
        bg = background_reliance(model, test_images, test_labels, dcfg, device)

        # shape and manipulation-check assertions
        any_out = prof["profile"][27][1]
        assert any_out["metrics"]["cosine"]["diff"].shape == (len(donor_plan),)
        assert any_out["manip_check"]["max_target_pixel_diff"] < 1e-6, name
        if name in LATTICE_MODELS:
            assert any_out["manip_check"]["stage1_invariant"] is True, f"stage1 not invariant: {name}"

        radius_by_model.setdefault(name, []).append(cci_r)
        points.append({"model": name, "seed": 1, "cci_radius": cci_r, "bg_gap": bg["bg_gap"]})
        print(f"[end_to_end/{name}] test_acc={acc['test_acc']:.3f} "
              f"cci_radius={cci_r:.4f} bg_gap={bg['bg_gap']:.4f} "
              f"manip_pix={any_out['manip_check']['max_target_pixel_diff']:.2e}")

        # two-stage for lattice models
        if name in LATTICE_MODELS:
            m2 = build_model(name, mcfg, num_classes)
            acc2 = train_two_stage(m2, loaders, tcfg, num_classes, device, seed=1)
            prof2 = spatial_profile(m2, test_images, test_labels, donor_plan, ccfg, device)
            cci_r2 = cci_radius_summary(prof2["scalars"], ccfg.target_tokens, ccfg.radii)
            radius_by_model[name].append(cci_r2)
            print(f"[two_stage/{name}]  test_acc={acc2['test_acc']:.3f} cci_radius={cci_r2:.4f}")

    # statistics
    a = np.array([radius_by_model[m][0] for m in LATTICE_MODELS])
    b = np.array([radius_by_model[m][0] for m in NATIVE_MODELS] + [a[0], a[1]])[:len(a)]
    test = paired_seed_test(a - b)
    print("paired_seed_test:", {k: (round(v, 4) if isinstance(v, float) else v)
                                 for k, v in test.items()})
    corr = pearson_with_ci([p["cci_radius"] for p in points],
                           [p["bg_gap"] for p in points], n_boot=200)
    print("correlation:", {k: (round(v, 4) if isinstance(v, float) else v) for k, v in corr.items()})

    # figures
    prof_for_plot = {m: [radius_by_model[m] and [radius_by_model[m][0]] * len(ccfg.radii)]
                     for m in LATTICE_MODELS}
    prof_for_plot = {m: np.array([[radius_by_model[m][0]] * len(ccfg.radii)]) for m in LATTICE_MODELS}
    plot_spatial_profiles(prof_for_plot, ccfg.radii, "/tmp/smoke_profiles.png")
    plot_cci_vs_bggap(points, "/tmp/smoke_scatter.png")

    print("\nSMOKE TEST PASSED")


if __name__ == "__main__":
    main()

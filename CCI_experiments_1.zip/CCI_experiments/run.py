"""
Usage:
    python run.py --dataset cifar10 --regime end_to_end
    python run.py --dataset cifar100 --models lattice_vit lattice_gat --seeds 1 7 13

"""

import argparse
import itertools
import json
import os
from typing import Dict, List

import numpy as np
import torch

from config import (ExperimentConfig, LATTICE_MODELS, NATIVE_MODELS)
from cci.data import DonorPlan, build_loaders, dataset_to_tensor, build_datasets
from cci.train import build_model, train_end_to_end, train_two_stage
from cci.experiments import (spatial_profile, cci_radius_summary,
                             cci_halfmax_radius, background_reliance)
from cci.analysis import (paired_seed_test, pearson_with_ci, holm,
                          plot_spatial_profiles, plot_cci_vs_bggap)


def _num_classes(dataset: str) -> int:
    return 100 if dataset == "cifar100" else 10


def _jsonable(obj):
    if isinstance(obj, dict):
        return {str(k): _jsonable(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_jsonable(v) for v in obj]
    if isinstance(obj, (np.floating, np.integer)):
        return obj.item()
    if isinstance(obj, np.ndarray):
        return obj.tolist()
    return obj


def run(cfg: ExperimentConfig) -> Dict:
    device = cfg.device if torch.cuda.is_available() else "cpu"
    os.makedirs(cfg.out_dir, exist_ok=True)
    num_classes = _num_classes(cfg.data.dataset)

    loaders = build_loaders(cfg.data)
    _, _, test_ds = build_datasets(cfg.data)
    test_images, test_labels = dataset_to_tensor(test_ds)
    donor_plan = DonorPlan(test_labels, cfg.cci.n_source,
                           cfg.cci.n_same_class_donors, cfg.cci.n_diff_class_donors,
                           cfg.cci.donor_seed)

    # Storage: results[regime][model] = per-seed lists.
    results: Dict = {}
    points: List[Dict] = []       # (model, seed, cci_radius, bg_gap) for correlation

    regimes = ["end_to_end", "two_stage"]
    for model_name in cfg.models:
        for regime in regimes:
            if regime == "two_stage" and model_name in NATIVE_MODELS:
                continue           # native backbones are end-to-end only
            key = f"{regime}/{model_name}"
            results[key] = {"test_acc": [], "cci_radius": [], "cci_halfmax": [],
                            "bg_gap": [], "seed_profile_diff": [], "manip_ok": []}
            for seed in cfg.seeds:
                model = build_model(model_name, cfg.model, num_classes)
                if regime == "end_to_end":
                    acc = train_end_to_end(model, loaders, cfg.train, device, seed)
                else:
                    acc = train_two_stage(model, loaders, cfg.train, num_classes, device, seed)

                prof = spatial_profile(model, test_images, test_labels, donor_plan,
                                       cfg.cci, device)
                sc = prof["scalars"]
                cci_r = cci_radius_summary(sc, cfg.cci.target_tokens, cfg.cci.radii)
                cci_hm = cci_halfmax_radius(sc, cfg.cci.target_tokens, cfg.cci.radii)
                bg = background_reliance(model, test_images, test_labels,
                                         cfg.downstream, device)

                # Seed-level movement per radius, averaged over target locations.
                seed_diff = [float(np.mean([sc[(t, r, "cosine", "diff")]
                                            for t in cfg.cci.target_tokens]))
                             for r in cfg.cci.radii]
                manip = all(prof["profile"][t][r]["manip_check"]["max_target_pixel_diff"] < 1e-6
                            for t in cfg.cci.target_tokens for r in cfg.cci.radii)

                results[key]["test_acc"].append(acc["test_acc"])
                results[key]["cci_radius"].append(cci_r)
                results[key]["cci_halfmax"].append(cci_hm)
                results[key]["bg_gap"].append(bg["bg_gap"])
                results[key]["seed_profile_diff"].append(seed_diff)
                results[key]["manip_ok"].append(manip)
                points.append({"model": key, "seed": seed,
                               "cci_radius": cci_r, "bg_gap": bg["bg_gap"]})
                print(f"[{key} seed {seed}] test_acc={acc['test_acc']:.4f} "
                      f"cci_radius={cci_r:.4f} bg_gap={bg['bg_gap']:.4f}")

    analysis = _analyse(results, cfg)

    # Correlation across all (model, seed) points (recommendation 8).
    corr = pearson_with_ci([p["cci_radius"] for p in points],
                           [p["bg_gap"] for p in points])
    analysis["cci_radius_vs_bg_gap"] = corr

    # Figures.
    end_to_end_profiles = {k.split("/", 1)[1]: v["seed_profile_diff"]
                           for k, v in results.items() if k.startswith("end_to_end/")}
    plot_spatial_profiles(end_to_end_profiles, cfg.cci.radii,
                          os.path.join(cfg.out_dir, "spatial_profiles.png"))
    plot_cci_vs_bggap(points, os.path.join(cfg.out_dir, "cci_vs_bggap.png"))

    out = {"config": {"dataset": cfg.data.dataset, "seeds": cfg.seeds,
                      "models": cfg.models, "radii": cfg.cci.radii,
                      "targets": cfg.cci.target_tokens},
           "results": results, "analysis": analysis}
    with open(os.path.join(cfg.out_dir, "results.json"), "w") as f:
        json.dump(_jsonable(out), f, indent=2)
    return out


def _analyse(results: Dict, cfg: ExperimentConfig) -> Dict:
    """Seed-level paired comparisons of the contextual radius between models."""
    analysis = {"accuracy": {}, "pairwise_cci_radius": {}}
    for key, r in results.items():
        analysis["accuracy"][key] = {"mean": float(np.mean(r["test_acc"])),
                                     "sd": float(np.std(r["test_acc"], ddof=1)) if len(r["test_acc"]) > 1 else 0.0}
    # Pairwise paired tests within each regime on the contextual radius.
    pvals, labels = [], []
    keys = list(results.keys())
    for a, b in itertools.combinations(keys, 2):
        ra, rb = a.split("/")[0], b.split("/")[0]
        if ra != rb:
            continue                      # compare like-trained models only
        if len(results[a]["cci_radius"]) != len(results[b]["cci_radius"]):
            continue
        diffs = np.array(results[a]["cci_radius"]) - np.array(results[b]["cci_radius"])
        test = paired_seed_test(diffs)
        analysis["pairwise_cci_radius"][f"{a} vs {b}"] = test
        pvals.append(test["p_t"])
        labels.append(f"{a} vs {b}")
    if pvals:
        for lab, adj in zip(labels, holm(pvals)):
            analysis["pairwise_cci_radius"][lab]["p_holm"] = adj
    return analysis


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", default="cifar10", choices=["cifar10", "cifar100"])
    ap.add_argument("--models", nargs="+", default=None)
    ap.add_argument("--seeds", nargs="+", type=int, default=None)
    ap.add_argument("--out_dir", default="./results")
    ap.add_argument("--epochs", type=int, default=None)
    args = ap.parse_args()

    cfg = ExperimentConfig()
    cfg.data.dataset = args.dataset
    cfg.out_dir = args.out_dir
    if args.models:
        cfg.models = args.models
    if args.seeds:
        cfg.seeds = args.seeds
    if args.epochs:
        cfg.train.epochs = args.epochs
    run(cfg)


if __name__ == "__main__":
    main()

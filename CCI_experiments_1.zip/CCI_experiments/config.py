"""
Central configuration for the CCI experiment suite.

This suite implements recommendations 6 to 10 of the referee report on
"When Locality Is Not Local: Context Dependence in Visual Representations":

    6.  Cross-architecture CCI at matched accuracy (shared-lattice ViT,
        windowed/Swin-style, GAT, stride-preserving CNN, plus native
        CIFAR ResNet-18 and native ViT).
    7.  Competent end-to-end training in addition to the paper's frozen
        two-stage protocol.
    8.  A downstream background-reliance test and its correlation with the
        CCI spatial radius.
    9.  At least ten training seeds and an honest treatment of the
        sign-flip permutation floor.
    10. Multiple target patch locations, not only token 27.

The code is self-contained. Reconcile the Stage-1 encoder details and the
channel normalisation constants with the original pipeline before quoting
absolute numbers against the current manuscript.
"""

from dataclasses import dataclass, field
from typing import List, Tuple


# CIFAR channel statistics (standard values).
CIFAR10_MEAN = (0.4914, 0.4822, 0.4465)
CIFAR10_STD = (0.2470, 0.2435, 0.2616)
CIFAR100_MEAN = (0.5071, 0.4865, 0.4409)
CIFAR100_STD = (0.2673, 0.2564, 0.2762)

# Geometry, fixed to the manuscript.
IMG_SIZE = 32
PATCH_SIZE = 4
GRID = IMG_SIZE // PATCH_SIZE          # 8
N_TOKENS = GRID * GRID                 # 64


@dataclass
class DataConfig:
    dataset: str = "cifar10"           # "cifar10" or "cifar100"
    root: str = "./data"
    val_size: int = 5000
    split_seed: int = 42               # fixed train/val split, as in the paper
    batch_size: int = 256
    num_workers: int = 4


@dataclass
class ModelConfig:
    # Shared Stage-1 patch encoder.
    embed_dim: int = 128               # token width (paper used 64; widen for competence)
    encoder_blocks: int = 3
    encoder_mlp_ratio: int = 2
    # Mixer depths for the shared-lattice backbones.
    depth: int = 4
    n_heads: int = 4
    swin_window: int = 4
    gat_layers: int = 2
    gat_heads: int = 4
    cnn_blocks: int = 4
    dropout: float = 0.0


@dataclass
class TrainConfig:
    regime: str = "end_to_end"         # "end_to_end" or "two_stage"
    epochs: int = 60                   # end-to-end target for competent accuracy
    encoder_epochs: int = 30           # Stage-1 in the two-stage regime
    mixer_epochs: int = 20             # Stage-2 in the two-stage regime
    lr: float = 3e-4
    weight_decay: float = 5e-2
    warmup_epochs: int = 5
    grad_clip: float = 5.0
    label_smoothing: float = 0.1
    amp: bool = True


@dataclass
class CCIConfig:
    # Primary intervention geometry.
    target_tokens: List[int] = field(default_factory=lambda: [27, 0, 4, 24, 45])
    radii: List[int] = field(default_factory=lambda: [1, 2, 3, 4, 5, 6])
    primary_radius: int = 2
    encoder_invariance_tol: float = 1e-4   # manipulation check tolerance (eq. 8)
    # Donor sampling plan.
    n_source: int = 1000
    n_same_class_donors: int = 3
    n_diff_class_donors: int = 3
    donor_seed: int = 819
    # Null/calibration baselines.
    run_null_baselines: bool = True        # identity, shuffled-same-image, noise donor
    # Metrics: cosine is primary; the rest are reported alongside.
    metrics: Tuple[str, ...] = ("cosine", "euclidean", "rel_euclidean")


@dataclass
class DownstreamConfig:
    # Background-reliance proxy for CIFAR (Mixed-Rand analogue without masks).
    # Foreground is a central patch neighbourhood of this Manhattan radius
    # around the grid centre; the surround is randomised with donors.
    foreground_radius: int = 2
    n_random_donors: int = 5
    n_eval_images: int = 2000
    eval_seed: int = 2024


@dataclass
class ExperimentConfig:
    seeds: List[int] = field(default_factory=lambda: [1, 7, 13, 21, 42, 57, 63, 88, 101, 123])
    models: List[str] = field(default_factory=lambda: [
        "lattice_vit", "lattice_swin", "lattice_gat", "lattice_cnn",
        "native_resnet18", "native_vit",
    ])
    out_dir: str = "./results"
    device: str = "cuda"               # falls back to cpu automatically
    data: DataConfig = field(default_factory=DataConfig)
    model: ModelConfig = field(default_factory=ModelConfig)
    train: TrainConfig = field(default_factory=TrainConfig)
    cci: CCIConfig = field(default_factory=CCIConfig)
    downstream: DownstreamConfig = field(default_factory=DownstreamConfig)


# The shared-lattice models expose a separable encoder and therefore support
# the two-stage regime. The native backbones mix across patch boundaries in
# early layers and are trained end-to-end only.
LATTICE_MODELS = ("lattice_vit", "lattice_swin", "lattice_gat", "lattice_cnn")
NATIVE_MODELS = ("native_resnet18", "native_vit")

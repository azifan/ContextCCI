"""
Data pipeline, patch geometry, and counterfactual image construction.

All token indexing is row-major on the 8x8 lattice:
    token t  ->  (row, col) = (t // GRID, t % GRID)
and a token owns the pixel block
    rows [row*PATCH_SIZE : (row+1)*PATCH_SIZE], cols [col*PATCH_SIZE : ...].
The same convention is used when native feature maps are reshaped to tokens,
so a native 8x8 feature vector at (row, col) matches lattice token row*GRID+col.
"""

from typing import Dict, List, Optional, Tuple

import numpy as np
import torch
from torch.utils.data import DataLoader, Subset

from config import (
    CIFAR10_MEAN, CIFAR10_STD, CIFAR100_MEAN, CIFAR100_STD,
    GRID, IMG_SIZE, N_TOKENS, PATCH_SIZE, DataConfig,
)


# ----------------------------------------------------------------------------
# Patch geometry
# ----------------------------------------------------------------------------
def token_to_rowcol(t: int) -> Tuple[int, int]:
    return t // GRID, t % GRID


def manhattan_from_target(target: int) -> np.ndarray:
    """Manhattan distance (in tokens) from every token to the target."""
    tr, tc = token_to_rowcol(target)
    d = np.empty(N_TOKENS, dtype=np.int64)
    for t in range(N_TOKENS):
        r, c = token_to_rowcol(t)
        d[t] = abs(r - tr) + abs(c - tc)
    return d


def protected_token_mask(target: int, radius: int) -> torch.Tensor:
    """Boolean [N_TOKENS]: True where the token is preserved (kept from source)."""
    d = manhattan_from_target(target)
    return torch.from_numpy(d <= radius)


def annular_token_mask(target: int, band_low: int, band_high: int) -> torch.Tensor:
    """Boolean [N_TOKENS]: True for tokens in the distance band (band_low, band_high].

    Used for the count-matched annular intervention: replace a fixed number of
    patches drawn only from a chosen distance band, so distance is decoupled
    from the number of replaced patches.
    """
    d = manhattan_from_target(target)
    return torch.from_numpy((d > band_low) & (d <= band_high))


def pixel_mask_from_tokens(token_mask: torch.Tensor) -> torch.Tensor:
    """Expand a [N_TOKENS] token mask to a [IMG_SIZE, IMG_SIZE] pixel mask."""
    grid = token_mask.view(GRID, GRID).float()
    pix = grid.repeat_interleave(PATCH_SIZE, 0).repeat_interleave(PATCH_SIZE, 1)
    return pix.bool()


def build_counterfactual(
    source: torch.Tensor, donor: torch.Tensor, protected_mask: torch.Tensor
) -> torch.Tensor:
    """Compose the counterfactual image.

    source, donor : [B, 3, H, W] (already normalised tensors)
    protected_mask: [N_TOKENS] bool, True where source pixels are preserved.
    Returns [B, 3, H, W] with preserved patches from source and the rest from donor.
    """
    pix = pixel_mask_from_tokens(protected_mask).to(source.device)  # [H, W]
    pix = pix.view(1, 1, IMG_SIZE, IMG_SIZE)
    return torch.where(pix, source, donor)


def target_patch_pixels(img: torch.Tensor, target: int) -> torch.Tensor:
    """Return the pixels of the target patch, [B, 3, PATCH_SIZE, PATCH_SIZE]."""
    r, c = token_to_rowcol(target)
    return img[:, :, r * PATCH_SIZE:(r + 1) * PATCH_SIZE,
              c * PATCH_SIZE:(c + 1) * PATCH_SIZE]


# ----------------------------------------------------------------------------
# CIFAR datasets
# ----------------------------------------------------------------------------
def _stats(dataset: str):
    return (CIFAR10_MEAN, CIFAR10_STD) if dataset == "cifar10" else (CIFAR100_MEAN, CIFAR100_STD)


def build_datasets(cfg: DataConfig):
    """Return (train, val, test) datasets with the paper's fixed split.

    Requires torchvision. Train uses random crop (pad 4) and horizontal flip.
    Val and test use only normalisation, so the CCI evaluation is deterministic.
    """
    import torchvision
    import torchvision.transforms as T

    mean, std = _stats(cfg.dataset)
    train_tf = T.Compose([
        T.RandomCrop(IMG_SIZE, padding=4),
        T.RandomHorizontalFlip(),
        T.ToTensor(),
        T.Normalize(mean, std),
    ])
    eval_tf = T.Compose([T.ToTensor(), T.Normalize(mean, std)])

    ds = torchvision.datasets.CIFAR10 if cfg.dataset == "cifar10" else torchvision.datasets.CIFAR100
    full_train = ds(cfg.root, train=True, download=True, transform=train_tf)
    full_train_eval = ds(cfg.root, train=True, download=True, transform=eval_tf)
    test = ds(cfg.root, train=False, download=True, transform=eval_tf)

    n = len(full_train)
    g = torch.Generator().manual_seed(cfg.split_seed)
    perm = torch.randperm(n, generator=g).tolist()
    val_idx = perm[:cfg.val_size]
    train_idx = perm[cfg.val_size:]
    train = Subset(full_train, train_idx)
    val = Subset(full_train_eval, val_idx)     # eval transform on validation
    return train, val, test


def build_loaders(cfg: DataConfig):
    train, val, test = build_datasets(cfg)
    mk = lambda d, s: DataLoader(d, batch_size=cfg.batch_size, shuffle=s,
                                 num_workers=cfg.num_workers, pin_memory=True, drop_last=False)
    return mk(train, True), mk(val, False), mk(test, False)


# ----------------------------------------------------------------------------
# Donor plan
# ----------------------------------------------------------------------------
class DonorPlan:
    """A fixed source/donor sampling plan, reused across models and seeds.

    Sampling is done once from the test set with a fixed seed so that every
    trained model is evaluated on identical counterfactual comparisons.
    """

    def __init__(self, labels: np.ndarray, n_source: int, n_same: int, n_diff: int, seed: int):
        rng = np.random.default_rng(seed)
        self.labels = labels
        n = len(labels)
        classes = np.unique(labels)
        by_class = {int(c): np.where(labels == c)[0] for c in classes}

        self.source_idx = rng.choice(n, size=min(n_source, n), replace=False)
        self.same: List[np.ndarray] = []
        self.diff: List[np.ndarray] = []
        for s in self.source_idx:
            c = int(labels[s])
            same_pool = by_class[c][by_class[c] != s]
            diff_pool = np.where(labels != c)[0]
            self.same.append(rng.choice(same_pool, size=n_same, replace=False))
            self.diff.append(rng.choice(diff_pool, size=n_diff, replace=False))
        self.same = np.stack(self.same)   # [n_source, n_same]
        self.diff = np.stack(self.diff)   # [n_source, n_diff]

    def __len__(self):
        return len(self.source_idx)


def dataset_to_tensor(dataset) -> Tuple[torch.Tensor, np.ndarray]:
    """Materialise an evaluation dataset to a single tensor of images and labels.

    Only used for CCI evaluation on the (normalised) test set. Fine for CIFAR.
    """
    loader = DataLoader(dataset, batch_size=512, shuffle=False, num_workers=0)
    imgs, labels = [], []
    for x, y in loader:
        imgs.append(x)
        labels.append(y)
    return torch.cat(imgs), torch.cat(labels).numpy()

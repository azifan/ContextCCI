"""
Shared-lattice backbones.

Every model here reuses one Stage-1 patch encoder that maps the image to 64
per-patch tokens, then applies a different mixing mechanism. Because the
tokenisation, the target token, and the CCI intervention are identical across
models, differences in the measured contextual profile are attributable to the
mixing mechanism rather than to differing input geometry.

All models return {"logits", "tokens", "stage1"} where "tokens" is the
post-mixing per-patch representation used as the CCI endpoint and "stage1" is
the pre-mixing encoder token used for the manipulation check (eq. 8).
"""

from typing import Dict

import torch
import torch.nn as nn
import torch.nn.functional as F

from config import GRID, N_TOKENS, ModelConfig


# ----------------------------------------------------------------------------
# Shared Stage-1 encoder (patchwise, no cross-token interaction)
# ----------------------------------------------------------------------------
class ResidualMLPBlock(nn.Module):
    def __init__(self, dim: int, ratio: int):
        super().__init__()
        self.norm = nn.LayerNorm(dim)
        self.fc1 = nn.Linear(dim, dim * ratio)
        self.fc2 = nn.Linear(dim * ratio, dim)

    def forward(self, x):
        return x + self.fc2(F.gelu(self.fc1(self.norm(x))))


class Stage1Encoder(nn.Module):
    """Conv patch embedding (stride = patch) then patchwise residual MLPs.

    The convolution has kernel = stride = PATCH_SIZE, so each token depends only
    on its own 4x4 patch. Holding the target patch fixed therefore leaves its
    Stage-1 token exactly unchanged, which is what the manipulation check tests.
    """

    def __init__(self, cfg: ModelConfig):
        super().__init__()
        d = cfg.embed_dim
        self.proj = nn.Conv2d(3, d, kernel_size=4, stride=4)
        self.pos = nn.Parameter(torch.zeros(1, N_TOKENS, d))
        nn.init.trunc_normal_(self.pos, std=0.02)
        self.blocks = nn.ModuleList(
            [ResidualMLPBlock(d, cfg.encoder_mlp_ratio) for _ in range(cfg.encoder_blocks)]
        )
        self.norm = nn.LayerNorm(d)

    def forward(self, x):
        z = self.proj(x)                       # [B, D, 8, 8]
        z = z.flatten(2).transpose(1, 2)       # [B, 64, D] row-major
        z = z + self.pos
        for blk in self.blocks:
            z = blk(z)
        return self.norm(z)


# ----------------------------------------------------------------------------
# Lattice adjacency (self + four neighbours)
# ----------------------------------------------------------------------------
def lattice_adjacency() -> torch.Tensor:
    rc = [(t // GRID, t % GRID) for t in range(N_TOKENS)]
    adj = torch.zeros(N_TOKENS, N_TOKENS, dtype=torch.bool)
    for i, (ri, ci) in enumerate(rc):
        for j, (rj, cj) in enumerate(rc):
            if abs(ri - rj) + abs(ci - cj) <= 1:   # self and 4-neighbours
                adj[i, j] = True
    return adj


# ----------------------------------------------------------------------------
# Mixers
# ----------------------------------------------------------------------------
class ViTMixer(nn.Module):
    def __init__(self, cfg: ModelConfig):
        super().__init__()
        d = cfg.embed_dim
        layer = nn.TransformerEncoderLayer(
            d_model=d, nhead=cfg.n_heads, dim_feedforward=d * cfg.encoder_mlp_ratio,
            dropout=cfg.dropout, activation="gelu", batch_first=True, norm_first=True,
        )
        self.enc = nn.TransformerEncoder(layer, num_layers=cfg.depth,
                                         enable_nested_tensor=False)

    def forward(self, tokens):
        return self.enc(tokens)


class SwinMixer(nn.Module):
    """Windowed multi-head attention on the 8x8 lattice with alternating shift.

    Simplified relative to Swin: shifted layers use a cyclic roll without the
    boundary attention mask. This is adequate as a local-to-global mixing probe
    and is documented as an approximation.
    """

    def __init__(self, cfg: ModelConfig):
        super().__init__()
        self.d = cfg.embed_dim
        self.w = cfg.swin_window
        self.depth = cfg.depth
        self.attn = nn.ModuleList([
            nn.MultiheadAttention(self.d, cfg.n_heads, dropout=cfg.dropout, batch_first=True)
            for _ in range(cfg.depth)
        ])
        self.norm = nn.ModuleList([nn.LayerNorm(self.d) for _ in range(cfg.depth)])
        self.mlp = nn.ModuleList([
            nn.Sequential(nn.LayerNorm(self.d), nn.Linear(self.d, self.d * 2),
                          nn.GELU(), nn.Linear(self.d * 2, self.d))
            for _ in range(cfg.depth)
        ])

    def _windows(self, grid):                   # grid [B, G, G, D] -> windows
        B, G, _, D = grid.shape
        w = self.w
        grid = grid.view(B, G // w, w, G // w, w, D)
        win = grid.permute(0, 1, 3, 2, 4, 5).reshape(-1, w * w, D)
        return win

    def _unwindows(self, win, B, G):
        w = self.w
        D = win.shape[-1]
        grid = win.view(B, G // w, G // w, w, w, D).permute(0, 1, 3, 2, 4, 5)
        return grid.reshape(B, G, G, D)

    def forward(self, tokens):
        B = tokens.shape[0]
        G = GRID
        x = tokens
        for i in range(self.depth):
            shift = (i % 2 == 1)
            grid = x.view(B, G, G, self.d)
            if shift:
                grid = torch.roll(grid, shifts=(self.w // 2, self.w // 2), dims=(1, 2))
            win = self._windows(grid)
            h = self.norm[i](win)
            a, _ = self.attn[i](h, h, h, need_weights=False)
            win = win + a
            grid = self._unwindows(win, B, G)
            if shift:
                grid = torch.roll(grid, shifts=(-(self.w // 2), -(self.w // 2)), dims=(1, 2))
            x = grid.reshape(B, N_TOKENS, self.d)
            x = x + self.mlp[i](x)
        return x


class GATLayer(nn.Module):
    """Multi-head graph attention on a fixed adjacency (self + 4 neighbours)."""

    def __init__(self, dim: int, heads: int, adj: torch.Tensor):
        super().__init__()
        assert dim % heads == 0
        self.h = heads
        self.dh = dim // heads
        self.W = nn.Linear(dim, dim, bias=False)
        self.a_src = nn.Parameter(torch.empty(heads, self.dh))
        self.a_dst = nn.Parameter(torch.empty(heads, self.dh))
        nn.init.xavier_uniform_(self.a_src)
        nn.init.xavier_uniform_(self.a_dst)
        self.leaky = nn.LeakyReLU(0.2)
        self.register_buffer("adj", adj)

    def forward(self, x):
        B, N, _ = x.shape
        Wh = self.W(x).view(B, N, self.h, self.dh)              # [B,N,H,Dh]
        e_src = torch.einsum("bnhd,hd->bnh", Wh, self.a_src)    # [B,N,H]
        e_dst = torch.einsum("bnhd,hd->bnh", Wh, self.a_dst)
        e = self.leaky(e_src.permute(0, 2, 1)[:, :, :, None]
                       + e_dst.permute(0, 2, 1)[:, :, None, :])  # [B,H,N,N]
        e = e.masked_fill(~self.adj[None, None], float("-inf"))
        alpha = torch.softmax(e, dim=-1)                        # over j
        out = torch.einsum("bhij,bjhd->bihd", alpha, Wh).reshape(B, N, self.h * self.dh)
        return out


class GATMixer(nn.Module):
    def __init__(self, cfg: ModelConfig):
        super().__init__()
        adj = lattice_adjacency()
        self.layers = nn.ModuleList(
            [GATLayer(cfg.embed_dim, cfg.gat_heads, adj) for _ in range(cfg.gat_layers)]
        )
        self.norm = nn.ModuleList([nn.LayerNorm(cfg.embed_dim) for _ in range(cfg.gat_layers)])

    def forward(self, tokens):
        x = tokens
        for layer, norm in zip(self.layers, self.norm):
            x = x + F.elu(layer(norm(x)))
        return x


class CNNMixer(nn.Module):
    """Stride-preserving convolutional mixer on the 8x8 token map."""

    def __init__(self, cfg: ModelConfig):
        super().__init__()
        d = cfg.embed_dim
        self.blocks = nn.ModuleList()
        for _ in range(cfg.cnn_blocks):
            self.blocks.append(nn.Sequential(
                nn.Conv2d(d, d, 3, padding=1), nn.GroupNorm(8, d), nn.GELU(),
                nn.Conv2d(d, d, 3, padding=1), nn.GroupNorm(8, d),
            ))

    def forward(self, tokens):
        B, N, D = tokens.shape
        x = tokens.transpose(1, 2).reshape(B, D, GRID, GRID)
        for blk in self.blocks:
            x = F.gelu(x + blk(x))
        return x.flatten(2).transpose(1, 2)


# ----------------------------------------------------------------------------
# Assembled lattice model
# ----------------------------------------------------------------------------
_MIXERS = {"lattice_vit": ViTMixer, "lattice_swin": SwinMixer,
           "lattice_gat": GATMixer, "lattice_cnn": CNNMixer}


class LatticeModel(nn.Module):
    def __init__(self, name: str, cfg: ModelConfig, num_classes: int):
        super().__init__()
        self.encoder = Stage1Encoder(cfg)
        self.mixer = _MIXERS[name](cfg)
        self.head = nn.Linear(cfg.embed_dim, num_classes)

    def forward(self, x) -> Dict[str, torch.Tensor]:
        s1 = self.encoder(x)
        tok = self.mixer(s1)
        logits = self.head(tok.mean(1))
        return {"logits": logits, "tokens": tok, "stage1": s1}


class Stage1Classifier(nn.Module):
    """Encoder plus a linear head on the mean token, for Stage-1 pretraining."""

    def __init__(self, encoder: Stage1Encoder, dim: int, num_classes: int):
        super().__init__()
        self.encoder = encoder
        self.head = nn.Linear(dim, num_classes)

    def forward(self, x):
        z = self.encoder(x)
        return {"logits": self.head(z.mean(1)), "tokens": z, "stage1": z}

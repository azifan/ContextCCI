"""
Experiment drivers: the spatial-scale profile (over radii and target
locations) and the downstream background-reliance test.
"""

from typing import Dict, List

import numpy as np
import torch

from config import CCIConfig, DownstreamConfig
from cci.data import build_counterfactual, protected_token_mask
from cci.intervention import run_cci, summarize_seed_level


# ----------------------------------------------------------------------------
# Spatial-scale profile (recommendations 6 and 10)
# ----------------------------------------------------------------------------
def spatial_profile(model, images, labels, donor_plan, cci_cfg: CCIConfig, device) -> Dict:
    """Full CCI profile for one trained model.

    Returns nested dict: profile[target][radius] = run_cci output, plus a
    seed-level scalar table keyed by (target, radius, metric, channel).
    """
    profile: Dict[int, Dict[int, Dict]] = {}
    scalars: Dict = {}
    for target in cci_cfg.target_tokens:
        profile[target] = {}
        for radius in cci_cfg.radii:
            out = run_cci(model, images, labels, donor_plan, target, radius, device,
                          metrics=cci_cfg.metrics,
                          invariance_tol=cci_cfg.encoder_invariance_tol)
            profile[target][radius] = out
            for m in cci_cfg.metrics:
                for ch in ("same", "diff", "contrast"):
                    scalars[(target, radius, m, ch)] = summarize_seed_level(out, m, ch)
    return {"profile": profile, "scalars": scalars}


def cci_radius_summary(scalars: Dict, targets: List[int], radii: List[int],
                       metric: str = "cosine", channel: str = "diff") -> float:
    """Summarise a model's spatial profile into one contextual-radius scalar.

    Area under the profile (sum of the per-radius movement over radii, averaged
    over target locations). A larger value means context dependence that stays
    high over a wider protected neighbourhood, that is a spatially more extended
    reliance on surrounding context.
    """
    per_target = []
    for t in targets:
        per_target.append(sum(scalars[(t, r, metric, channel)] for r in radii))
    return float(np.mean(per_target))


def cci_halfmax_radius(scalars: Dict, targets: List[int], radii: List[int],
                       metric: str = "cosine", channel: str = "diff") -> float:
    """Smallest radius at which the movement drops below half its value at radii[0],
    averaged over targets. An alternative, scale-free summary of spatial extent."""
    outs = []
    for t in targets:
        base = scalars[(t, radii[0], metric, channel)]
        half = 0.5 * base
        hit = next((r for r in radii if scalars[(t, r, metric, channel)] < half), radii[-1])
        outs.append(hit)
    return float(np.mean(outs))


# ----------------------------------------------------------------------------
# Downstream background reliance (recommendation 8)
# ----------------------------------------------------------------------------
@torch.no_grad()
def _accuracy_on(model, imgs, labels, device, batch=512) -> float:
    correct = 0
    for i in range(0, imgs.shape[0], batch):
        xb = imgs[i:i + batch].to(device)
        pred = model(xb)["logits"].argmax(-1).cpu().numpy()
        correct += (pred == labels[i:i + batch]).sum()
    return float(correct) / len(labels)


@torch.no_grad()
def background_reliance(model, images, labels, dcfg: DownstreamConfig, device,
                        center_token: int = 27) -> Dict:
    """A CIFAR proxy for Mixed-Rand background reliance.

    A central foreground neighbourhood is preserved while the surround is
    replaced by random different-class donors. The accuracy drop is the
    background-reliance score (BG-Gap). On CIFAR, where objects are largely
    centred, this is a defensible proxy; on ImageNet-9 one would use the true
    foreground masks of the Backgrounds Challenge (Xiao et al. 2021).
    """
    rng = np.random.default_rng(dcfg.eval_seed)
    n = min(dcfg.n_eval_images, images.shape[0])
    idx = rng.choice(images.shape[0], size=n, replace=False)
    eval_imgs, eval_labels = images[idx], labels[idx]

    clean_acc = _accuracy_on(model, eval_imgs, eval_labels, device)

    foreground = protected_token_mask(center_token, dcfg.foreground_radius)
    rand_accs = []
    for _ in range(dcfg.n_random_donors):
        donor_idx = np.array([
            rng.choice(np.where(labels != eval_labels[k])[0]) for k in range(n)
        ])
        donors = images[donor_idx]
        cf = build_counterfactual(eval_imgs, donors, foreground)
        rand_accs.append(_accuracy_on(model, cf, eval_labels, device))
    randomized_acc = float(np.mean(rand_accs))
    return {"clean_acc": clean_acc, "randomized_acc": randomized_acc,
            "bg_gap": clean_acc - randomized_acc}

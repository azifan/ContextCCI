"""CCI experiment suite (recommendations 6 to 10 of the referee report)."""

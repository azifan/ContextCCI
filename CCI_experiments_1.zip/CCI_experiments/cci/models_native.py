"""
Native backbones with a per-patch representation tap.

These are standard architectures, included for external validity. The CCI
endpoint is the per-patch representation at the 8x8 stage.

Manipulation-check caveat. For the native ResNet the early convolutions mix
information across patch boundaries before the tap point, so the pre-mixing
target token is not exactly invariant under the intervention and "stage1" is
returned as None. For the native ViT the patch embedding is patchwise, so the
target patch embedding is invariant and the check applies at that layer.
Interpret native-model displacements with this asymmetry in mind, which is
itself a reason the shared-lattice suite is the cleaner controlled comparison.
"""

from typing import Dict, Optional

import torch
import torch.nn as nn
import torch.nn.functional as F

from config import GRID, N_TOKENS, ModelConfig


# ----------------------------------------------------------------------------
# CIFAR ResNet-18, tapped at the 8x8 stage (layer3)
# ----------------------------------------------------------------------------
class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, cin, cout, stride=1):
        super().__init__()
        self.conv1 = nn.Conv2d(cin, cout, 3, stride, 1, bias=False)
        self.bn1 = nn.BatchNorm2d(cout)
        self.conv2 = nn.Conv2d(cout, cout, 3, 1, 1, bias=False)
        self.bn2 = nn.BatchNorm2d(cout)
        self.short = nn.Sequential()
        if stride != 1 or cin != cout:
            self.short = nn.Sequential(
                nn.Conv2d(cin, cout, 1, stride, bias=False), nn.BatchNorm2d(cout))

    def forward(self, x):
        out = F.relu(self.bn1(self.conv1(x)))
        out = self.bn2(self.conv2(out))
        return F.relu(out + self.short(x))


class NativeResNet18(nn.Module):
    def __init__(self, num_classes: int, tap_dim: int = 256):
        super().__init__()
        self.conv1 = nn.Conv2d(3, 64, 3, 1, 1, bias=False)
        self.bn1 = nn.BatchNorm2d(64)
        self.layer1 = self._make(64, 64, 2, 1)     # 32x32
        self.layer2 = self._make(64, 128, 2, 2)    # 16x16
        self.layer3 = self._make(128, 256, 2, 2)   # 8x8  <- CCI tap
        self.layer4 = self._make(256, 512, 2, 2)   # 4x4
        self.head = nn.Linear(512, num_classes)
        self.tap_dim = tap_dim

    def _make(self, cin, cout, n, stride):
        layers = [BasicBlock(cin, cout, stride)]
        for _ in range(n - 1):
            layers.append(BasicBlock(cout, cout, 1))
        return nn.Sequential(*layers)

    def forward(self, x) -> Dict[str, Optional[torch.Tensor]]:
        x = F.relu(self.bn1(self.conv1(x)))
        x = self.layer1(x)
        x = self.layer2(x)
        f8 = self.layer3(x)                          # [B, 256, 8, 8]
        tokens = f8.flatten(2).transpose(1, 2)       # [B, 64, 256] row-major
        x = self.layer4(f8)
        logits = self.head(F.adaptive_avg_pool2d(x, 1).flatten(1))
        return {"logits": logits, "tokens": tokens, "stage1": None}


# ----------------------------------------------------------------------------
# Native ViT (patch 4), tapped at the final patch tokens
# ----------------------------------------------------------------------------
class NativeViT(nn.Module):
    def __init__(self, num_classes: int, cfg: ModelConfig):
        super().__init__()
        d = cfg.embed_dim
        self.proj = nn.Conv2d(3, d, 4, 4)
        self.cls = nn.Parameter(torch.zeros(1, 1, d))
        self.pos = nn.Parameter(torch.zeros(1, N_TOKENS + 1, d))
        nn.init.trunc_normal_(self.pos, std=0.02)
        nn.init.trunc_normal_(self.cls, std=0.02)
        layer = nn.TransformerEncoderLayer(
            d_model=d, nhead=cfg.n_heads, dim_feedforward=d * cfg.encoder_mlp_ratio,
            dropout=cfg.dropout, activation="gelu", batch_first=True, norm_first=True)
        self.enc = nn.TransformerEncoder(layer, num_layers=cfg.depth,
                                         enable_nested_tensor=False)
        self.norm = nn.LayerNorm(d)
        self.head = nn.Linear(d, num_classes)

    def forward(self, x) -> Dict[str, torch.Tensor]:
        z = self.proj(x).flatten(2).transpose(1, 2)      # [B, 64, D] patchwise
        patch_embed = z + self.pos[:, 1:, :]             # invariant per patch
        cls = self.cls.expand(z.shape[0], -1, -1) + self.pos[:, :1, :]
        h = torch.cat([cls, patch_embed], dim=1)
        h = self.enc(h)
        h = self.norm(h)
        tokens = h[:, 1:, :]                              # [B, 64, D] post-mixing
        logits = self.head(h[:, 0, :])
        return {"logits": logits, "tokens": tokens, "stage1": patch_embed}


def build_native(name: str, cfg: ModelConfig, num_classes: int) -> nn.Module:
    if name == "native_resnet18":
        return NativeResNet18(num_classes)
    if name == "native_vit":
        return NativeViT(num_classes, cfg)
    raise ValueError(name)

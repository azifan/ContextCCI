"""
The Counterfactual Context Instantiation (CCI) measurement.

Given a trained model exposing a uniform interface

    out = model(images)            # dict with
    out["logits"]  : [B, C]
    out["tokens"]  : [B, N_TOKENS, D]   per-patch representation (the CCI endpoint)
    out["stage1"]  : optional [B, N_TOKENS, D_enc] pre-mixing tokens, for the
                     manipulation check (eq. 8). Present for lattice models.

CCI holds the target patch (and, in the radius sweep, a protected neighbourhood)
pixel-identical while replacing the remaining patches with donor content, then
measures how far the target token representation moves. Displacement is reported
separately from prediction change.
"""

from typing import Dict, List, Optional

import numpy as np
import torch

from config import N_TOKENS
from cci.data import (
    build_counterfactual, protected_token_mask, target_patch_pixels,
)


# ----------------------------------------------------------------------------
# Displacement metrics
# ----------------------------------------------------------------------------
def cosine_displacement(z0: torch.Tensor, z1: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    """1 - cosine similarity, per row. z0, z1: [B, D]. Returns [B]."""
    num = (z0 * z1).sum(-1)
    den = z0.norm(dim=-1).clamp_min(eps) * z1.norm(dim=-1).clamp_min(eps)
    return 1.0 - num / den


def euclidean_displacement(z0: torch.Tensor, z1: torch.Tensor) -> torch.Tensor:
    return (z1 - z0).norm(dim=-1)


def rel_euclidean_displacement(z0: torch.Tensor, z1: torch.Tensor, eps: float = 1e-8) -> torch.Tensor:
    return (z1 - z0).norm(dim=-1) / z0.norm(dim=-1).clamp_min(eps)


_METRIC_FNS = {
    "cosine": cosine_displacement,
    "euclidean": euclidean_displacement,
    "rel_euclidean": rel_euclidean_displacement,
}


def linear_cka(X: torch.Tensor, Y: torch.Tensor) -> float:
    """Linear CKA between two [N, D] representation matrices.

    A population-level, rotation- and isotropic-scale-invariant measure of how
    similar the original and counterfactual target-representation sets are.
    Returned as a similarity in [0, 1]; 1 - CKA is a robust displacement.
    """
    X = X - X.mean(0, keepdim=True)
    Y = Y - Y.mean(0, keepdim=True)
    # Frobenius inner products of Gram matrices, via the cross-covariance trick.
    xy = (X.t() @ Y).norm() ** 2
    xx = (X.t() @ X).norm()
    yy = (Y.t() @ Y).norm()
    denom = (xx * yy).clamp_min(1e-12)
    return float((xy / denom).item())


# ----------------------------------------------------------------------------
# Core CCI evaluation
# ----------------------------------------------------------------------------
@torch.no_grad()
def _target_reps(model, images: torch.Tensor, target: int, device: str,
                 want_stage1: bool = False, batch: int = 512):
    """Forward the model and return the target token representation.

    Returns (tokens_target [N, D], logits_argmax [N], stage1_target or None).
    """
    reps, preds, s1 = [], [], []
    for i in range(0, images.shape[0], batch):
        xb = images[i:i + batch].to(device)
        out = model(xb)
        reps.append(out["tokens"][:, target, :].float().cpu())
        preds.append(out["logits"].argmax(-1).cpu())
        if want_stage1 and ("stage1" in out) and (out["stage1"] is not None):
            s1.append(out["stage1"][:, target, :].float().cpu())
    reps = torch.cat(reps)
    preds = torch.cat(preds)
    s1 = torch.cat(s1) if (want_stage1 and s1) else None
    return reps, preds, s1


@torch.no_grad()
def run_cci(
    model,
    images: torch.Tensor,          # [N_all, 3, H, W] normalised (the test tensor)
    labels: np.ndarray,
    donor_plan,
    target: int,
    radius: int,
    device: str,
    metrics=("cosine", "euclidean", "rel_euclidean"),
    check_invariance: bool = True,
    invariance_tol: float = 1e-4,
) -> Dict:
    """Run CCI for one (target, radius) over the donor plan.

    Averages the donors within each source and donor-class, so the unit carried
    forward is the source-level effect. Returns per-source arrays for same-class
    and different-class context substitution, plus the class-sensitive contrast.
    """
    model.eval()
    protected = protected_token_mask(target, radius)

    src_idx = donor_plan.source_idx
    sources = images[src_idx]                                   # [S, 3, H, W]
    z_src, pred_src, s1_src = _target_reps(model, sources, target, device,
                                           want_stage1=check_invariance)

    results = {m: {"same": np.zeros(len(src_idx)), "diff": np.zeros(len(src_idx))}
               for m in metrics}
    predchange = {"same": np.zeros(len(src_idx)), "diff": np.zeros(len(src_idx))}
    max_target_pixel_diff = 0.0
    max_stage1_diff = 0.0

    for kind, donor_table in (("same", donor_plan.same), ("diff", donor_plan.diff)):
        n_donor = donor_table.shape[1]
        acc = {m: np.zeros(len(src_idx)) for m in metrics}
        acc_pc = np.zeros(len(src_idx))
        for j in range(n_donor):
            donors = images[donor_table[:, j]]                  # [S, 3, H, W]
            cf = build_counterfactual(sources, donors, protected)

            # Manipulation check: target patch pixels must be unchanged.
            dpix = (target_patch_pixels(cf, target) - target_patch_pixels(sources, target)).abs().max()
            max_target_pixel_diff = max(max_target_pixel_diff, float(dpix))

            z_cf, pred_cf, s1_cf = _target_reps(model, cf, target, device,
                                                want_stage1=check_invariance)
            if s1_src is not None and s1_cf is not None:
                max_stage1_diff = max(max_stage1_diff,
                                      float((s1_cf - s1_src).abs().max()))
            for m in metrics:
                acc[m] += _METRIC_FNS[m](z_src, z_cf).numpy()
            acc_pc += (pred_cf != pred_src).numpy().astype(float)
        for m in metrics:
            results[m][kind] = acc[m] / n_donor
        predchange[kind] = acc_pc / n_donor

    # Class-sensitive contrast: different-class minus same-class movement.
    contrast = {m: results[m]["diff"] - results[m]["same"] for m in metrics}

    return {
        "target": target,
        "radius": radius,
        "n_source": len(src_idx),
        "metrics": {m: {"same": results[m]["same"],
                        "diff": results[m]["diff"],
                        "contrast": contrast[m]} for m in metrics},
        "pred_change": predchange,
        "manip_check": {
            "max_target_pixel_diff": max_target_pixel_diff,
            "max_stage1_token_diff": max_stage1_diff,
            "stage1_invariant": (max_stage1_diff <= invariance_tol) if s1_src is not None else None,
        },
    }


def summarize_seed_level(cci_out: Dict, metric: str = "cosine", channel: str = "diff") -> float:
    """Reduce a run_cci result to one seed-level scalar (mean over sources)."""
    return float(cci_out["metrics"][metric][channel].mean())

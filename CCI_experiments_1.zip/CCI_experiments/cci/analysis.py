"""
Seed-level statistics and figures.

Statistics are self-contained (no SciPy dependency). The Student-t two-sided
p-value uses a regularised incomplete beta function.
"""

import math
from typing import Dict, List, Sequence

import numpy as np


# ----------------------------------------------------------------------------
# Student-t two-sided p-value via the regularised incomplete beta function
# ----------------------------------------------------------------------------
def _betacf(a, b, x, itmax=200, eps=3e-12):
    qab, qap, qam = a + b, a + 1.0, a - 1.0
    c = 1.0
    d = 1.0 - qab * x / qap
    d = 1.0 / (d if abs(d) > 1e-30 else 1e-30)
    h = d
    for m in range(1, itmax + 1):
        m2 = 2 * m
        aa = m * (b - m) * x / ((qam + m2) * (a + m2))
        d = 1.0 + aa * d
        d = 1.0 / (d if abs(d) > 1e-30 else 1e-30)
        c = 1.0 + aa / (c if abs(c) > 1e-30 else 1e-30)
        h *= d * c
        aa = -(a + m) * (qab + m) * x / ((a + m2) * (qap + m2))
        d = 1.0 + aa * d
        d = 1.0 / (d if abs(d) > 1e-30 else 1e-30)
        c = 1.0 + aa / (c if abs(c) > 1e-30 else 1e-30)
        delta = d * c
        h *= delta
        if abs(delta - 1.0) < eps:
            break
    return h


def _betai(a, b, x):
    if x <= 0.0:
        return 0.0
    if x >= 1.0:
        return 1.0
    lbeta = math.lgamma(a + b) - math.lgamma(a) - math.lgamma(b)
    bt = math.exp(lbeta + a * math.log(x) + b * math.log(1.0 - x))
    if x < (a + 1.0) / (a + b + 2.0):
        return bt * _betacf(a, b, x) / a
    return 1.0 - bt * _betacf(b, a, 1.0 - x) / b


def t_two_sided_p(t: float, df: float) -> float:
    if df <= 0:
        return float("nan")
    x = df / (df + t * t)
    return _betai(0.5 * df, 0.5, x)


# ----------------------------------------------------------------------------
# Paired seed-level test
# ----------------------------------------------------------------------------
def paired_seed_test(diffs: Sequence[float]) -> Dict:
    """Paired within-seed differences (model A minus model B), one per seed."""
    d = np.asarray(diffs, dtype=float)
    n = len(d)
    mean = float(d.mean())
    sd = float(d.std(ddof=1)) if n > 1 else float("nan")
    se = sd / math.sqrt(n) if n > 1 else float("nan")
    df = n - 1
    t = mean / se if se and se > 0 else float("nan")
    # 95% t critical value via bisection on the two-sided p.
    tcrit = _t_critical(0.05, df) if n > 1 else float("nan")
    ci = (mean - tcrit * se, mean + tcrit * se) if n > 1 else (float("nan"), float("nan"))
    dz = mean / sd if sd and sd > 0 else float("nan")

    # Exact two-sided sign-flip permutation test.
    mags = np.abs(d)
    obs = abs(mean)
    count = 0
    for bits in range(1 << n):
        signs = np.array([1.0 if (bits >> i) & 1 else -1.0 for i in range(n)])
        if abs((signs * mags).mean()) >= obs - 1e-12:
            count += 1
    signflip_p = count / (1 << n)
    signflip_floor = 2.0 / (1 << n)

    return {
        "n": n, "mean": mean, "sd": sd, "se": se, "df": df,
        "t": t, "p_t": t_two_sided_p(t, df) if n > 1 else float("nan"),
        "ci_low": ci[0], "ci_high": ci[1], "cohen_dz": dz,
        "n_positive": int((d > 0).sum()),
        "signflip_p": signflip_p, "signflip_floor": signflip_floor,
        "signflip_can_reject_05": signflip_floor < 0.05,
    }


def _t_critical(alpha: float, df: int) -> float:
    lo, hi = 0.0, 100.0
    for _ in range(100):
        mid = 0.5 * (lo + hi)
        if t_two_sided_p(mid, df) > alpha:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


# ----------------------------------------------------------------------------
# Multiplicity control
# ----------------------------------------------------------------------------
def holm(pvals: Sequence[float]) -> List[float]:
    p = np.asarray(pvals, float)
    order = np.argsort(p)
    m = len(p)
    adj = np.empty(m)
    running = 0.0
    for rank, idx in enumerate(order):
        val = (m - rank) * p[idx]
        running = max(running, val)
        adj[idx] = min(1.0, running)
    return adj.tolist()


def benjamini_hochberg(pvals: Sequence[float]) -> List[float]:
    p = np.asarray(pvals, float)
    m = len(p)
    order = np.argsort(p)
    adj = np.empty(m)
    prev = 1.0
    for rank in range(m - 1, -1, -1):
        idx = order[rank]
        val = p[idx] * m / (rank + 1)
        prev = min(prev, val)
        adj[idx] = min(1.0, prev)
    return adj.tolist()


# ----------------------------------------------------------------------------
# Correlation (recommendation 8): CCI radius vs background reliance
# ----------------------------------------------------------------------------
def pearson_with_ci(x: Sequence[float], y: Sequence[float], n_boot: int = 5000,
                    seed: int = 0) -> Dict:
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    n = len(x)
    r = float(np.corrcoef(x, y)[0, 1]) if n > 1 else float("nan")
    t = r * math.sqrt((n - 2) / (1 - r * r)) if (n > 2 and abs(r) < 1) else float("nan")
    p = t_two_sided_p(t, n - 2) if n > 2 else float("nan")
    rho = float(np.corrcoef(_rank(x), _rank(y))[0, 1]) if n > 1 else float("nan")
    rng = np.random.default_rng(seed)
    boots = []
    for _ in range(n_boot):
        idx = rng.integers(0, n, n)
        if np.std(x[idx]) > 0 and np.std(y[idx]) > 0:
            boots.append(np.corrcoef(x[idx], y[idx])[0, 1])
    ci = (float(np.percentile(boots, 2.5)), float(np.percentile(boots, 97.5))) if boots else (float("nan"),) * 2
    return {"pearson_r": r, "p": p, "ci_low": ci[0], "ci_high": ci[1],
            "spearman_rho": rho, "n": n}


def _rank(a: np.ndarray) -> np.ndarray:
    order = a.argsort()
    ranks = np.empty_like(order, dtype=float)
    ranks[order] = np.arange(len(a))
    return ranks


# ----------------------------------------------------------------------------
# Figures
# ----------------------------------------------------------------------------
def plot_spatial_profiles(profiles_by_model: Dict[str, Dict], radii: List[int],
                          out_path: str, metric: str = "cosine", channel: str = "diff"):
    """profiles_by_model[model] = array [n_seeds, n_radii] of seed-level movement."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    fig, ax = plt.subplots(figsize=(7, 5))
    for model, arr in profiles_by_model.items():
        arr = np.asarray(arr)
        mean = arr.mean(0)
        se = arr.std(0, ddof=1) / math.sqrt(arr.shape[0]) if arr.shape[0] > 1 else np.zeros_like(mean)
        ax.errorbar(radii, mean, yerr=1.96 * se, marker="o", capsize=3, label=model)
    ax.set_xlabel("Protected radius")
    ax.set_ylabel(f"Contextual-instantiation effect ({metric}, {channel})")
    ax.set_title("Cross-architecture spatial-scale profile")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)


def plot_cci_vs_bggap(points: List[Dict], out_path: str):
    """points: list of {model, seed, cci_radius, bg_gap}."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    x = [p["cci_radius"] for p in points]
    y = [p["bg_gap"] for p in points]
    stat = pearson_with_ci(x, y)
    fig, ax = plt.subplots(figsize=(6, 5))
    models = sorted({p["model"] for p in points})
    for model in models:
        mx = [p["cci_radius"] for p in points if p["model"] == model]
        my = [p["bg_gap"] for p in points if p["model"] == model]
        ax.scatter(mx, my, label=model, s=30)
    ax.set_xlabel("CCI contextual radius (area under profile)")
    ax.set_ylabel("Background-reliance gap (clean minus randomised acc)")
    ax.set_title(f"Pearson r = {stat['pearson_r']:.3f} "
                 f"[{stat['ci_low']:.3f}, {stat['ci_high']:.3f}], p = {stat['p']:.3g}")
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return stat

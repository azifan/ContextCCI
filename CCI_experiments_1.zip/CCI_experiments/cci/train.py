"""
Training: competent end-to-end, and the paper's frozen two-stage protocol.

The two-stage regime applies to the shared-lattice models, which expose a
separable encoder. Native backbones are trained end-to-end only.
"""

import math
import random
from typing import Dict, Optional, Tuple

import numpy as np
import torch
import torch.nn as nn

from config import LATTICE_MODELS, ModelConfig, TrainConfig
from cci.models_lattice import LatticeModel, Stage1Classifier
from cci.models_native import build_native


def set_seed(seed: int):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def build_model(name: str, cfg: ModelConfig, num_classes: int) -> nn.Module:
    if name in LATTICE_MODELS:
        return LatticeModel(name, cfg, num_classes)
    return build_native(name, cfg, num_classes)


def _optim_sched(params, tcfg: TrainConfig, steps_per_epoch: int, epochs: int):
    opt = torch.optim.AdamW(params, lr=tcfg.lr, weight_decay=tcfg.weight_decay)
    total = steps_per_epoch * epochs
    warm = steps_per_epoch * tcfg.warmup_epochs

    def lr_lambda(step):
        if step < warm:
            return (step + 1) / max(1, warm)
        prog = (step - warm) / max(1, total - warm)
        return 0.5 * (1 + math.cos(math.pi * prog))

    sched = torch.optim.lr_scheduler.LambdaLR(opt, lr_lambda)
    return opt, sched


@torch.no_grad()
def evaluate(model, loader, device) -> float:
    model.eval()
    correct = total = 0
    for x, y in loader:
        x, y = x.to(device), y.to(device)
        pred = model(x)["logits"].argmax(-1)
        correct += (pred == y).sum().item()
        total += y.numel()
    return correct / max(1, total)


def _train_loop(model, train_loader, val_loader, params, tcfg, device, epochs) -> Tuple[dict, float]:
    opt, sched = _optim_sched(params, tcfg, len(train_loader), epochs)
    device_type = "cuda" if device.startswith("cuda") else "cpu"
    use_amp = tcfg.amp and device_type == "cuda"
    scaler = torch.amp.GradScaler("cuda", enabled=use_amp)
    crit = nn.CrossEntropyLoss(label_smoothing=tcfg.label_smoothing)
    best_state, best_acc = None, -1.0

    for _ in range(epochs):
        model.train()
        for x, y in train_loader:
            x, y = x.to(device), y.to(device)
            opt.zero_grad(set_to_none=True)
            with torch.amp.autocast(device_type, enabled=use_amp):
                loss = crit(model(x)["logits"], y)
            scaler.scale(loss).backward()
            if tcfg.grad_clip:
                scaler.unscale_(opt)
                nn.utils.clip_grad_norm_(params, tcfg.grad_clip)
            scaler.step(opt)
            scaler.update()
            sched.step()
        acc = evaluate(model, val_loader, device)
        if acc > best_acc:
            best_acc = acc
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
    if best_state is not None:
        model.load_state_dict(best_state)
    return best_state, best_acc


def train_end_to_end(model, loaders, tcfg: TrainConfig, device, seed: int) -> Dict:
    set_seed(seed)
    train_loader, val_loader, test_loader = loaders
    model.to(device)
    _, best_val = _train_loop(model, train_loader, val_loader,
                              list(model.parameters()), tcfg, device, tcfg.epochs)
    return {"val_acc": best_val, "test_acc": evaluate(model, test_loader, device)}


def train_two_stage(model: LatticeModel, loaders, tcfg: TrainConfig,
                    num_classes: int, device, seed: int) -> Dict:
    """Stage 1: train encoder with a linear head. Stage 2: freeze encoder, train mixer."""
    set_seed(seed)
    train_loader, val_loader, test_loader = loaders
    model.to(device)

    dim = model.head.in_features
    stage1 = Stage1Classifier(model.encoder, dim, num_classes).to(device)
    _train_loop(stage1, train_loader, val_loader, list(stage1.parameters()),
                tcfg, device, tcfg.encoder_epochs)

    for p in model.encoder.parameters():          # freeze encoder
        p.requires_grad_(False)
    mixer_params = [p for p in model.parameters() if p.requires_grad]
    _, best_val = _train_loop(model, train_loader, val_loader, mixer_params,
                              tcfg, device, tcfg.mixer_epochs)
    return {"val_acc": best_val, "test_acc": evaluate(model, test_loader, device)}

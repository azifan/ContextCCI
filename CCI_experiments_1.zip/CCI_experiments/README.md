# CCI experiment suite

A self-contained PyTorch implementation of recommendations 6 to 10 from the
referee report on *When Locality Is Not Local: Context Dependence in Visual
Representations*. It measures Counterfactual Context Instantiation (CCI) across
several architectures, at competent accuracy, links the CCI spatial profile to a
downstream property, uses at least ten seeds, and sweeps multiple target
locations.

The code follows the manuscript protocol but is written from scratch. Reconcile
the Stage-1 encoder details and the channel normalisation constants with the
original pipeline before comparing absolute numbers to the current results.

## What each recommendation maps to

- **6. Cross-architecture CCI.** `cci/models_lattice.py` provides four backbones
  on a shared 8x8 patch lattice (ViT, windowed/Swin-style, GAT on the four
  neighbour graph, and a stride-preserving CNN), all sharing one Stage-1 encoder
  so the target token and the intervention are identical across models.
  `cci/models_native.py` adds a native CIFAR ResNet-18 and a native ViT for
  external validity, with the target representation tapped at the 8x8 stage.
- **7. Competent training.** `cci/train.py` trains each backbone end-to-end
  (target above 90 per cent on CIFAR-10) and also runs the paper's frozen
  two-stage regime for the lattice models, so the effect can be compared at both
  low and competent accuracy.
- **8. Downstream link.** `cci/experiments.py::background_reliance` measures a
  background-reliance gap on a Mixed-Rand-style proxy, and
  `cci/analysis.py::pearson_with_ci` correlates it with the CCI contextual
  radius across models and seeds.
- **9. Seeds and the sign-flip floor.** The default is ten seeds. `paired_seed_test`
  reports the paired t result, a 95 per cent confidence interval, Cohen's dz, and
  the exact sign-flip test together with its permutation floor and whether that
  floor can reach 0.05 at all.
- **10. Multiple target locations.** `CCIConfig.target_tokens` defaults to five
  locations spanning centre, corner and edges, and every profile is computed per
  location.

## Layout

```
config.py               all configuration dataclasses and geometry constants
run.py                  orchestrator (train, measure, compare, plot, save)
smoke_test.py           CPU synthetic-data sanity run, no CIFAR download
requirements.txt
cci/
  data.py               CIFAR loaders, patch geometry, counterfactual builder, donor plan
  intervention.py       CCI measurement, displacement metrics, linear CKA, manipulation check
  models_lattice.py     shared Stage-1 encoder and the four lattice backbones
  models_native.py      native CIFAR ResNet-18 and native ViT with a per-patch tap
  train.py              end-to-end and frozen two-stage training, multi-seed
  experiments.py        spatial-scale profile and background-reliance test
  analysis.py           seed-level statistics, multiplicity control, correlation, figures
```

## Quick start

```bash
pip install -r requirements.txt

# 1. Verify the machinery on CPU with synthetic data (about one minute).
python smoke_test.py

# 2. Full run on a GPU.
python run.py --dataset cifar10
python run.py --dataset cifar100 --models lattice_vit lattice_gat native_vit
```

Outputs land in `./results`: `results.json` (accuracies, per-model contextual
radius, background-reliance gaps, pairwise seed-level tests, and the
radius-versus-reliance correlation) plus `spatial_profiles.png` and
`cci_vs_bggap.png`.

## Design decisions and caveats

- **Uniform model interface.** Every model returns `{"logits", "tokens",
  "stage1"}`. `tokens` is the per-patch representation used as the CCI endpoint.
  `stage1` is the pre-mixing token, present for the shared-lattice models and the
  native ViT, used for the manipulation check.
- **Manipulation check.** `run_cci` verifies that the target patch pixels are
  unchanged and, where `stage1` is available, that the pre-mixing target token is
  invariant to within tolerance. For the native ResNet the early convolutions mix
  across patch boundaries before the tap, so `stage1` is `None` and the check does
  not apply. This asymmetry is why the shared-lattice suite is the cleaner
  controlled comparison and the native models are supporting evidence.
- **Metric calibration.** Cosine displacement is the primary endpoint. Euclidean
  and relative Euclidean are reported alongside, and `linear_cka` provides a
  population-level, rotation-invariant check of the ordering. For the camera-ready
  version, add the null baselines (identity donor, shuffled same-image donor,
  noise donor) via the same `build_counterfactual` path and report movement
  relative to them.
- **Count-matched annular intervention.** `cci/data.py::annular_token_mask` is
  provided so the distance band can be varied while the number of replaced
  patches is held fixed. This is the control that separates the spatial profile
  from the patch-count confound (referee recommendation 2) and plugs directly
  into `run_cci` in place of the protected mask.
- **Background-reliance proxy.** CIFAR has no foreground masks, so a central patch
  neighbourhood is treated as foreground and the surround is randomised. On
  ImageNet-9 use the true masks of the Backgrounds Challenge instead. The proxy is
  a stand-in, documented as such.
- **Contextual-radius summary.** Two summaries are provided: area under the
  profile (`cci_radius_summary`) and the half-maximum radius
  (`cci_halfmax_radius`). Both reduce a model's profile to one scalar for the
  cross-model correlation.

## Compute

A full CIFAR-10 run over six models, two regimes where applicable, and ten seeds
is of the order of a few GPU-days at the default 60 epochs, dominated by
training. The CCI measurement itself is cheap. Reduce `epochs`, `n_source`, or the
model or seed lists for faster turnarounds. The suite falls back to CPU
automatically if no GPU is present.
